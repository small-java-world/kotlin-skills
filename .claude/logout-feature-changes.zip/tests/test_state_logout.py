from __future__ import annotations

import pytest

from src.secure_auth_store import SecureAuthStoreError
from src.state import ClientState


def _new_logged_in_state(server_base_url: str = "https://server.example") -> ClientState:
    state = ClientState.new(server_base_url=server_base_url, audit_id="audit-1")
    state.audit_plan_session_id = "plan-1"
    state.access_token = "access-token"
    state.refresh_token = "refresh-token"
    state.token_expires_at = 1_700_000_000
    return state


def test_logout_clears_credential_and_state_fields(tmp_path, fake_keyring):
    state_path = tmp_path / "state.json"
    state = _new_logged_in_state()
    state.analysis_scope_id = "scope-1"
    state.save(state_path)
    credential_id = state.auth_credential_id
    assert credential_id is not None

    state.logout(state_path)

    assert state.auth_credential_id is None
    assert state.access_token is None
    assert state.refresh_token is None
    assert state.token_expires_at is None
    assert fake_keyring.get_password("the-auditor-desktop-session", credential_id) is None

    reloaded = ClientState.load(state_path)
    assert reloaded.auth_credential_id is None
    assert reloaded.access_token is None
    assert reloaded.token_expires_at is None
    # Non-auth fields (audit/recording config) are left untouched.
    assert reloaded.analysis_scope_id == "scope-1"
    assert reloaded.audit_plan_session_id == "plan-1"
    assert reloaded.server_base_url == "https://server.example"


def test_logout_succeeds_when_nothing_was_ever_saved(tmp_path, fake_keyring):
    state_path = tmp_path / "state.json"
    state = ClientState.new(server_base_url="https://server.example")

    state.logout(state_path)  # no credential id -> deletion is a no-op

    assert state.auth_credential_id is None
    assert fake_keyring.store == {}


def test_logout_raises_and_preserves_state_on_credential_manager_failure(tmp_path, fake_keyring):
    state_path = tmp_path / "state.json"
    state = _new_logged_in_state()
    state.save(state_path)
    credential_id = state.auth_credential_id

    fake_keyring.fail_delete = True  # deletion keeps failing; entry stays present

    with pytest.raises(SecureAuthStoreError):
        state.logout(state_path)

    # In-memory fields must not be cleared when deletion actually failed.
    assert state.auth_credential_id == credential_id
    assert state.access_token == "access-token"

    # The on-disk state must not have been rewritten to drop the credential.
    reloaded = ClientState.load(state_path)
    assert reloaded.auth_credential_id == credential_id
    assert reloaded.access_token == "access-token"


def test_logout_dev_does_not_touch_prod_credential(tmp_path, fake_keyring):
    prod_path = tmp_path / "state.json"
    dev_path = tmp_path / "state.dev.json"

    prod_state = _new_logged_in_state("https://prod.example")
    prod_state.save(prod_path)

    dev_state = _new_logged_in_state("https://dev.example")
    dev_state.save(dev_path)

    dev_state.logout(dev_path)

    prod_reloaded = ClientState.load(prod_path)
    assert prod_reloaded.access_token == "access-token"
    assert prod_reloaded.auth_credential_id is not None

    dev_reloaded = ClientState.load(dev_path)
    assert dev_reloaded.access_token is None
    assert dev_reloaded.auth_credential_id is None

from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fake_keyring import FakeKeyring  # noqa: E402
from src import secure_auth_store  # noqa: E402


@pytest.fixture
def fake_keyring(monkeypatch) -> FakeKeyring:
    """Redirect secure_auth_store's keyring calls to an in-memory double."""
    fake = FakeKeyring()
    monkeypatch.setattr(secure_auth_store, "_keyring", lambda: fake)
    return fake

from __future__ import annotations

from pathlib import Path

import pytest

from src.secure_auth_store import (
    SecureAuthStoreError,
    delete_auth_session_strict,
    save_auth_session,
)

PROD_STATE_PATH = Path("C:/fake-home/.the-auditor/windows-client/state.json")
DEV_STATE_PATH = Path("C:/fake-home/.the-auditor/windows-client/state.dev.json")


def test_delete_auth_session_strict_removes_entry(fake_keyring):
    credential_id = save_auth_session(
        PROD_STATE_PATH, access_token="at", refresh_token="rt",
    )
    delete_auth_session_strict(PROD_STATE_PATH, credential_id)
    assert fake_keyring.store == {}


def test_delete_auth_session_strict_noop_without_credential_id(fake_keyring):
    delete_auth_session_strict(PROD_STATE_PATH, None)
    assert fake_keyring.store == {}


def test_delete_auth_session_strict_missing_entry_counts_as_success(fake_keyring):
    # Nothing was ever saved under this credential id (or it was already
    # deleted) — delete_password() raises, but a follow-up lookup confirms
    # there is nothing left, so this must not raise.
    fake_keyring.fail_delete = True
    delete_auth_session_strict(PROD_STATE_PATH, "11111111-1111-1111-1111-111111111111")


def test_delete_auth_session_strict_real_failure_raises(fake_keyring):
    credential_id = save_auth_session(
        PROD_STATE_PATH, access_token="at", refresh_token="rt",
    )
    fake_keyring.fail_delete = True  # entry stays in the store — a genuine failure
    with pytest.raises(SecureAuthStoreError):
        delete_auth_session_strict(PROD_STATE_PATH, credential_id)
    # The credential must still be considered present after the failure.
    assert len(fake_keyring.store) == 1


def test_delete_auth_session_strict_treats_transient_delete_error_as_success(fake_keyring):
    # Backend reports an error from delete_password() but the entry is
    # actually gone when we re-check — must not raise.
    credential_id = save_auth_session(
        PROD_STATE_PATH, access_token="at", refresh_token="rt",
    )
    fake_keyring.fail_delete = True
    fake_keyring.fail_delete_but_removes_entry = True
    delete_auth_session_strict(PROD_STATE_PATH, credential_id)
    assert fake_keyring.store == {}


def test_delete_auth_session_strict_raises_when_verification_itself_fails(fake_keyring):
    credential_id = save_auth_session(
        PROD_STATE_PATH, access_token="at", refresh_token="rt",
    )
    fake_keyring.fail_delete = True
    fake_keyring.fail_verify_lookup = True
    with pytest.raises(SecureAuthStoreError):
        delete_auth_session_strict(PROD_STATE_PATH, credential_id)


def test_dev_and_prod_use_separate_keyring_entries(fake_keyring):
    save_auth_session(PROD_STATE_PATH, access_token="prod-at", refresh_token="prod-rt")
    dev_id = save_auth_session(DEV_STATE_PATH, access_token="dev-at", refresh_token="dev-rt")

    delete_auth_session_strict(DEV_STATE_PATH, dev_id)

    # Only the dev entry was removed — prod's entry lives under a distinct
    # Credential Manager service name and must survive.
    assert len(fake_keyring.store) == 1
    remaining_service = next(iter(fake_keyring.store))[0]
    assert remaining_service == "the-auditor-desktop-session"

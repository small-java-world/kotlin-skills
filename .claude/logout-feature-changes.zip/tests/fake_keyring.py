"""In-memory keyring double for secure_auth_store tests.

Stands in for the third-party `keyring` module that secure_auth_store.py
imports lazily via `_keyring()`, so tests never touch the real Windows
Credential Manager.
"""

from __future__ import annotations


class FakeKeyringError(Exception):
    pass


class FakeKeyring:
    """Exposes get/set/delete_password backed by an in-memory dict.

    Failure injection knobs let tests exercise secure_auth_store's error
    handling without a real backend:
    - fail_delete: delete_password() always raises.
    - fail_delete_but_removes_entry: combined with fail_delete, simulates a
      backend that removed the entry but still reported an error (still
      counts as a successful deletion once verified).
    - fail_verify_lookup: get_password() raises, simulating a backend that
      can't even be asked whether the entry survived a failed delete.
    """

    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}
        self.fail_delete = False
        self.fail_delete_but_removes_entry = False
        self.fail_verify_lookup = False

    def set_password(self, service: str, username: str, password: str) -> None:
        self.store[(service, username)] = password

    def get_password(self, service: str, username: str) -> str | None:
        if self.fail_verify_lookup:
            raise FakeKeyringError("verification lookup failed")
        return self.store.get((service, username))

    def delete_password(self, service: str, username: str) -> None:
        key = (service, username)
        if self.fail_delete:
            if self.fail_delete_but_removes_entry:
                self.store.pop(key, None)
            raise FakeKeyringError("delete_password failed")
        if key not in self.store:
            raise FakeKeyringError("password not found")
        del self.store[key]

"""GUI logout flow tests.

These build a bare `gui.App` via `App.__new__` instead of running the real
`__init__` (which enumerates audio devices, builds a Tk window, and drives
the startup login flow). `_logout()` only touches a handful of instance
attributes plus tkinter.messagebox / self.after_cancel / self.destroy, all
of which are stubbed below, so the real business logic (state.py,
secure_auth_store.py) still runs against the fake keyring / a temp home
directory.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import pytest

import gui
from src.state import ClientState, default_state_path


def _bare_app() -> gui.App:
    app = gui.App.__new__(gui.App)
    app._checking_audit_day = False
    app._proc = None
    app._test_active = False
    app._auth_env_overrides = {"THE_AUDITOR_EMAIL": "a@example.com", "THE_AUDITOR_PASSWORD": "pw"}
    app._level_after = None
    app._mock_procs = []
    app.after_cancel = MagicMock()
    app.destroy = MagicMock()
    return app


@pytest.fixture(autouse=True)
def _isolate_home(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))


@pytest.fixture(autouse=True)
def _stub_messagebox(monkeypatch):
    monkeypatch.setattr(gui.messagebox, "askyesno", lambda *a, **k: True)
    monkeypatch.setattr(gui.messagebox, "showerror", lambda *a, **k: None)
    monkeypatch.setattr(gui.messagebox, "showinfo", lambda *a, **k: None)


def _save_logged_in_state(app_environment: str, *, server_base_url: str) -> Path:
    state_path = default_state_path(app_environment)
    state = ClientState.new(server_base_url=server_base_url, audit_id="audit-1")
    state.access_token = "access-token"
    state.refresh_token = "refresh-token"
    state.token_expires_at = 1_700_000_000
    state.save(state_path)
    return state_path


def test_logout_blocked_while_recording(monkeypatch, fake_keyring):
    app = _bare_app()
    app._proc = object()  # stands in for a running capture subprocess
    ask = MagicMock(return_value=True)
    monkeypatch.setattr(gui.messagebox, "askyesno", ask)

    app._logout()

    ask.assert_not_called()
    app.destroy.assert_not_called()


def test_logout_blocked_during_audio_test(monkeypatch, fake_keyring):
    app = _bare_app()
    app._test_active = True
    ask = MagicMock(return_value=True)
    monkeypatch.setattr(gui.messagebox, "askyesno", ask)

    app._logout()

    ask.assert_not_called()
    app.destroy.assert_not_called()


def test_logout_blocked_during_scope_check(monkeypatch, fake_keyring):
    app = _bare_app()
    app._checking_audit_day = True
    ask = MagicMock(return_value=True)
    monkeypatch.setattr(gui.messagebox, "askyesno", ask)

    app._logout()

    ask.assert_not_called()
    app.destroy.assert_not_called()


def test_logout_cancelled_deletes_nothing(monkeypatch, fake_keyring):
    monkeypatch.setattr(gui, "_current_app_environment", lambda: "prod")
    state_path = _save_logged_in_state("prod", server_base_url="https://prod.example")
    assert len(fake_keyring.store) == 1

    app = _bare_app()
    monkeypatch.setattr(gui.messagebox, "askyesno", lambda *a, **k: False)

    app._logout()

    assert len(fake_keyring.store) == 1
    reloaded = ClientState.load(state_path)
    assert reloaded.access_token == "access-token"
    app.destroy.assert_not_called()


def test_logout_success_deletes_credential_and_exits(monkeypatch, fake_keyring):
    monkeypatch.setattr(gui, "_current_app_environment", lambda: "prod")
    state_path = _save_logged_in_state("prod", server_base_url="https://prod.example")

    app = _bare_app()
    info = MagicMock()
    error = MagicMock()
    monkeypatch.setattr(gui.messagebox, "showinfo", info)
    monkeypatch.setattr(gui.messagebox, "showerror", error)

    app._logout()

    error.assert_not_called()
    info.assert_called_once()
    assert fake_keyring.store == {}
    reloaded = ClientState.load(state_path)
    assert reloaded.auth_credential_id is None
    assert reloaded.access_token is None
    assert reloaded.token_expires_at is None
    assert app._auth_env_overrides == {}
    app.destroy.assert_called_once()


def test_logout_succeeds_when_never_logged_in(monkeypatch, fake_keyring):
    monkeypatch.setattr(gui, "_current_app_environment", lambda: "prod")
    app = _bare_app()
    info = MagicMock()
    error = MagicMock()
    monkeypatch.setattr(gui.messagebox, "showinfo", info)
    monkeypatch.setattr(gui.messagebox, "showerror", error)

    app._logout()

    error.assert_not_called()
    info.assert_called_once()
    app.destroy.assert_called_once()


def test_logout_credential_manager_failure_shows_error_and_stays_open(monkeypatch, fake_keyring):
    monkeypatch.setattr(gui, "_current_app_environment", lambda: "prod")
    state_path = _save_logged_in_state("prod", server_base_url="https://prod.example")
    fake_keyring.fail_delete = True  # Credential Manager deletion keeps failing

    app = _bare_app()
    info = MagicMock()
    error = MagicMock()
    monkeypatch.setattr(gui.messagebox, "showinfo", info)
    monkeypatch.setattr(gui.messagebox, "showerror", error)

    app._logout()

    info.assert_not_called()
    error.assert_called_once()
    assert len(fake_keyring.store) == 1  # credential still present
    reloaded = ClientState.load(state_path)
    assert reloaded.access_token == "access-token"  # state untouched
    app.destroy.assert_not_called()


def test_logout_then_restart_has_no_usable_auth_state(monkeypatch, fake_keyring):
    monkeypatch.setattr(gui, "_current_app_environment", lambda: "prod")
    _save_logged_in_state("prod", server_base_url="https://prod.example")

    app = _bare_app()
    app._logout()

    fresh_app = _bare_app()
    fresh_app._auth_env_overrides = {}
    assert fresh_app._has_usable_auth_state({}) is False


def test_logout_dev_env_does_not_delete_prod_credential(monkeypatch, fake_keyring):
    prod_path = _save_logged_in_state("prod", server_base_url="https://prod.example")
    dev_path = _save_logged_in_state("dev", server_base_url="https://dev.example")
    assert len(fake_keyring.store) == 2

    monkeypatch.setattr(gui, "_current_app_environment", lambda: "dev")
    app = _bare_app()

    app._logout()

    assert len(fake_keyring.store) == 1
    prod_reloaded = ClientState.load(prod_path)
    assert prod_reloaded.access_token == "access-token"
    assert prod_reloaded.auth_credential_id is not None

    dev_reloaded = ClientState.load(dev_path)
    assert dev_reloaded.access_token is None
    assert dev_reloaded.auth_credential_id is None
    app.destroy.assert_called_once()

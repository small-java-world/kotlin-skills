from __future__ import annotations

import json
import uuid
from dataclasses import dataclass
from pathlib import Path


_KEYRING_SERVICE_BASE = "the-auditor-desktop-session"


class SecureAuthStoreError(RuntimeError):
    pass


def _keyring_service_for(state_path: Path) -> str:
    """Derive the Credential Manager service name from the state file name.

    default_state_path() names Dev's state file "state.dev.json" (Prod stays
    "state.json" for backward compatibility) — reusing that same suffix here
    keeps Dev and Prod credentials in separate Credential Manager entries
    instead of the single shared one they used to clobber.

    --state-file lets a caller point at an arbitrary path that doesn't follow
    that "state[.env].json" convention; naively slicing off the first 5
    characters would then chop into the real name instead of finding a
    suffix (e.g. "my_state.json" -> "ate"). Key off the whole stem instead
    so any custom path still gets its own distinct, if unlovely, service.
    """
    stem = state_path.stem
    if stem == "state":
        return _KEYRING_SERVICE_BASE
    if stem.startswith("state."):
        return _KEYRING_SERVICE_BASE + stem[len("state"):].replace(".", "-")
    return f"{_KEYRING_SERVICE_BASE}-{stem}"


@dataclass(frozen=True)
class StoredAuthSession:
    access_token: str
    refresh_token: str


def _keyring():
    try:
        import keyring  # type: ignore[import-untyped]
    except ImportError as error:
        raise SecureAuthStoreError("Windows Credential Manager support is unavailable") from error
    return keyring


def _credential_id(value: str | None = None) -> str:
    if value is None:
        return str(uuid.uuid4())
    try:
        return str(uuid.UUID(value))
    except (ValueError, AttributeError, TypeError) as error:
        raise SecureAuthStoreError("Invalid desktop credential id") from error


def save_auth_session(
    state_path: Path,
    *,
    access_token: str,
    refresh_token: str,
    credential_id: str | None = None,
) -> str:
    resolved_id = _credential_id(credential_id)
    payload = json.dumps(
        {
            "version": 1,
            "accessToken": access_token,
            "refreshToken": refresh_token,
        },
        separators=(",", ":"),
    )
    try:
        _keyring().set_password(_keyring_service_for(state_path), resolved_id, payload)
    except Exception as error:
        raise SecureAuthStoreError(
            "Windows Credential Manager could not protect the desktop session"
        ) from error
    return resolved_id


def load_auth_session(state_path: Path, credential_id: str) -> StoredAuthSession:
    resolved_id = _credential_id(credential_id)
    try:
        raw = _keyring().get_password(_keyring_service_for(state_path), resolved_id)
        if raw is None:
            raise SecureAuthStoreError("The protected desktop session was not found")
        payload = json.loads(raw)
        access_token = payload["accessToken"]
        refresh_token = payload["refreshToken"]
    except SecureAuthStoreError:
        raise
    except Exception as error:
        raise SecureAuthStoreError("The protected desktop session is unavailable") from error
    if not isinstance(access_token, str) or not isinstance(refresh_token, str):
        raise SecureAuthStoreError("The protected desktop session is invalid")
    return StoredAuthSession(access_token=access_token, refresh_token=refresh_token)


def delete_auth_session(state_path: Path, credential_id: str | None) -> None:
    if not credential_id:
        return
    try:
        _keyring().delete_password(_keyring_service_for(state_path), _credential_id(credential_id))
    except Exception:
        pass


def delete_auth_session_strict(state_path: Path, credential_id: str | None) -> None:
    """Delete the Credential Manager entry, raising if it might still exist.

    delete_auth_session() above is best-effort and silently swallows
    failures, because its callers (state.save()'s rollback path,
    clear_auth_session()) must never raise. The logout flow needs the
    opposite guarantee: a real deletion failure has to surface as an error
    instead of being reported to the user as a successful logout. A missing
    entry (already deleted, or never saved) is not a failure — that's
    confirmed by re-reading the entry after a failed delete_password() call.
    """
    if not credential_id:
        return
    service = _keyring_service_for(state_path)
    resolved_id = _credential_id(credential_id)
    keyring_module = _keyring()
    try:
        keyring_module.delete_password(service, resolved_id)
        return
    except Exception:
        pass
    try:
        remaining = keyring_module.get_password(service, resolved_id)
    except Exception as error:
        raise SecureAuthStoreError(
            "Windows Credential Manager から認証情報を削除できませんでした"
        ) from error
    if remaining is not None:
        raise SecureAuthStoreError(
            "Windows Credential Manager から認証情報を削除できませんでした"
        )

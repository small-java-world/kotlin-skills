from __future__ import annotations

import json
import os
import stat
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from .secure_auth_store import (
    SecureAuthStoreError,
    delete_auth_session,
    delete_auth_session_strict,
    load_auth_session,
    save_auth_session,
)


def default_state_path(app_environment: str = "prod") -> Path:
    # Prod keeps the original bare "state.json" so existing installs are
    # unaffected; Dev gets its own file so the two environments (which
    # otherwise share the same $HOME) no longer clobber each other's audit
    # scope / session / credential reference. See secure_auth_store.py,
    # which derives its Credential Manager service name from this filename.
    suffix = "" if app_environment == "prod" else f".{app_environment}"
    return Path.home() / ".the-auditor" / "windows-client" / f"state{suffix}.json"


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _derive_audit_id(audit_id: str, external_audit_id: str) -> str:
    return audit_id


def _optional_text(value: object) -> str:
    return "" if value is None else str(value)


_SCOPED_UUID_AUDIT_KEY_RE = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}-\d+$"
)


def reject_scoped_audit_identifier(value: str) -> None:
    raw = value.strip()
    if raw.startswith("audit:") or _SCOPED_UUID_AUDIT_KEY_RE.match(raw):
        raise RuntimeError("Use the scope UUID, not a scoped analyzer id")


@dataclass
class ClientState:
    version: int
    server_base_url: str
    audit_id: str
    desktop_capture_identifier: str
    analysis_scope_id: str
    audit_plan_session_id: str
    external_audit_id: str
    scoped_audit_key: str
    recording_session_id: str | None
    session_queue_key: str | None
    session_id: str | None
    audit_case_code: str | None
    business_timezone: str
    business_day_boundary_local_time: str
    updated_at: str
    auth_credential_id: str | None = None
    access_token: str | None = None
    refresh_token: str | None = None
    token_expires_at: int | None = None

    @staticmethod
    def new(
        *,
        server_base_url: str,
        audit_id: str | None = None,
        external_audit_id: str = "",
    ) -> "ClientState":
        return ClientState(
            version=1,
            server_base_url=server_base_url,
            audit_id=_derive_audit_id(audit_id or "", external_audit_id),
            desktop_capture_identifier="",
            analysis_scope_id="",
            audit_plan_session_id="",
            external_audit_id=external_audit_id,
            scoped_audit_key="",
            recording_session_id=None,
            session_queue_key=None,
            session_id=None,
            audit_case_code=None,
            business_timezone="Asia/Tokyo",
            business_day_boundary_local_time="05:00:00",
            updated_at=_now_iso(),
        )

    def set_audit_id(self, audit_id: str) -> None:
        reject_scoped_audit_identifier(audit_id)
        if self.audit_id == audit_id:
            return
        self.audit_id = audit_id
        self.desktop_capture_identifier = ""
        self.analysis_scope_id = ""
        self.audit_plan_session_id = ""
        self.external_audit_id = ""
        self.scoped_audit_key = ""
        self.recording_session_id = None
        self.session_queue_key = None
        self.session_id = None

    def set_desktop_capture_identifier(self, desktop_capture_identifier: str) -> None:
        normalized = desktop_capture_identifier.strip()
        if self.desktop_capture_identifier == normalized:
            return
        self.desktop_capture_identifier = normalized
        self.analysis_scope_id = ""
        self.audit_plan_session_id = ""
        self.external_audit_id = ""
        self.scoped_audit_key = ""
        self.recording_session_id = None
        self.session_queue_key = None
        self.session_id = None

    @staticmethod
    def load(path: Path) -> "ClientState":
        obj = json.loads(path.read_text(encoding="utf-8"))
        token_expires_at = obj.get("tokenExpiresAt")
        external_audit_id = str(obj.get("externalAuditId", ""))
        audit_id = _derive_audit_id(str(obj.get("auditId", "")), external_audit_id)
        state = ClientState(
            version=int(obj.get("version", 1)),
            server_base_url=str(obj.get("serverBaseUrl", "")),
            audit_id=audit_id,
            desktop_capture_identifier=str(obj.get("desktopCaptureIdentifier", "")),
            analysis_scope_id=str(obj.get("analysisScopeId", "")),
            audit_plan_session_id=_optional_text(obj.get("auditPlanSessionId", "")),
            external_audit_id=external_audit_id,
            scoped_audit_key=str(obj.get("scopedAuditKey", "")),
            recording_session_id=obj.get("recordingSessionId"),
            session_queue_key=obj.get("sessionQueueKey"),
            session_id=obj.get("sessionId"),
            audit_case_code=obj.get("auditCaseCode"),
            business_timezone=str(obj.get("businessTimezone", "Asia/Tokyo")),
            business_day_boundary_local_time=str(obj.get("businessDayBoundaryLocalTime", "05:00:00")),
            updated_at=str(obj.get("updatedAt", _now_iso())),
            auth_credential_id=obj.get("authCredentialId"),
            token_expires_at=int(token_expires_at) if token_expires_at is not None else None,
        )
        if state.auth_credential_id:
            try:
                session = load_auth_session(path, state.auth_credential_id)
                state.access_token = session.access_token
                state.refresh_token = session.refresh_token
            except SecureAuthStoreError:
                pass

        # One-time migration: consume legacy plaintext fields, then immediately
        # rewrite state.json without either token. On Windows save() moves them
        # into the per-user DPAPI store; elsewhere the session is not persisted.
        legacy_access_token = obj.get("accessToken")
        legacy_refresh_token = obj.get("refreshToken")
        if isinstance(legacy_access_token, str) or isinstance(legacy_refresh_token, str):
            state.access_token = legacy_access_token if isinstance(legacy_access_token, str) else None
            state.refresh_token = legacy_refresh_token if isinstance(legacy_refresh_token, str) else None
            state.save(path)
        return state

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        secure_store_error: SecureAuthStoreError | None = None
        persisted_credential_id = self.auth_credential_id
        persisted_token_expires_at = self.token_expires_at
        if self.access_token is not None and self.refresh_token is not None:
            try:
                self.auth_credential_id = save_auth_session(
                    path,
                    access_token=self.access_token,
                    refresh_token=self.refresh_token,
                    credential_id=self.auth_credential_id,
                )
                persisted_credential_id = self.auth_credential_id
            except SecureAuthStoreError as error:
                secure_store_error = error
                delete_auth_session(path, self.auth_credential_id)
                self.auth_credential_id = None
                persisted_credential_id = None
                persisted_token_expires_at = None
        payload = {
            "version": self.version,
            "serverBaseUrl": self.server_base_url,
            "auditId": self.audit_id,
            "desktopCaptureIdentifier": self.desktop_capture_identifier,
            "analysisScopeId": self.analysis_scope_id,
            "auditPlanSessionId": self.audit_plan_session_id,
            "externalAuditId": self.external_audit_id,
            "scopedAuditKey": self.scoped_audit_key,
            "recordingSessionId": self.recording_session_id,
            "sessionQueueKey": self.session_queue_key,
            "sessionId": self.session_id,
            "auditCaseCode": self.audit_case_code,
            "businessTimezone": self.business_timezone,
            "businessDayBoundaryLocalTime": self.business_day_boundary_local_time,
            "updatedAt": _now_iso(),
            "authCredentialId": persisted_credential_id,
            "tokenExpiresAt": persisted_token_expires_at,
        }
        # Write to a temp file then atomically replace to avoid corruption on crash.
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, path)
        try:
            path.chmod(stat.S_IRUSR | stat.S_IWUSR)
        except Exception:
            pass
        if secure_store_error is not None and os.name == "nt":
            raise secure_store_error

    def clear_auth_session(self, path: Path) -> None:
        delete_auth_session(path, self.auth_credential_id)
        self.auth_credential_id = None
        self.access_token = None
        self.refresh_token = None
        self.token_expires_at = None

    def logout(self, path: Path) -> None:
        """Delete the Credential Manager entry and clear the persisted session.

        Unlike clear_auth_session(), a Credential Manager deletion failure is
        raised (SecureAuthStoreError) instead of swallowed: the desktop
        GUI's logout flow must not clear the on-disk session, report success,
        or exit the app when the credential might still be sitting in
        Credential Manager. audit/recording fields on this state are left
        untouched — only the auth fields are cleared, and only on success.
        """
        delete_auth_session_strict(path, self.auth_credential_id)
        self.auth_credential_id = None
        self.access_token = None
        self.refresh_token = None
        self.token_expires_at = None
        self.save(path)

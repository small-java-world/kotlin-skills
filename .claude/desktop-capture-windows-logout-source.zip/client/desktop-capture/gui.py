"""Desktop Audio Capture — GUI launcher.

Run directly:
    python gui.py
Or create a shortcut to:
    pythonw gui.py
"""

from __future__ import annotations

import json
import logging
import math
import os
import queue
import subprocess
import sys
import threading
import time
import tkinter as tk
from tkinter import messagebox, simpledialog
from pathlib import Path
from tkinter import ttk
from types import SimpleNamespace

import sounddevice as sd

from src.json_config import load_json_config, normalize_app_environment
from src.log_setup import configure as configure_logging
from src.scope_readiness_api import format_scope_readiness_display_name
from src.scope_identifier import JA_MESSAGES, desktop_capture_identifier_error
from src.single_instance import SingleInstanceLock

try:
    import pyaudiowpatch as _pa
    _HAS_PYAUDIO = True
except ImportError:
    _HAS_PYAUDIO = False

ROOT = Path(__file__).parent
CONFIG_DIR = ROOT / "config"
LOG_DIR = Path.home() / ".the-auditor" / "logs"
_GUI_PREFS_PATH = Path.home() / ".the-auditor" / "gui_prefs.json"

APP_VERSION = "1.0.1"

MOCK_API_PORT = 8765

STARTUP_AUTH_READY = "ready"
STARTUP_AUTH_CANCELLED = "cancelled"
STARTUP_AUTH_DEFERRED = "deferred"

logger = logging.getLogger("desktop-capture.gui")


def _configured_string(value: object) -> str:
    if not isinstance(value, str):
        return ""
    value = value.strip()
    if not value or value.startswith("<") or value.isupper() or "YOUR_" in value:
        return ""
    return value


def _desktop_capture_identifier_error(identifier: str, mode: str) -> str | None:
    return desktop_capture_identifier_error(identifier, mock=mode == "mock", messages=JA_MESSAGES)


# ---------------------------------------------------------------------------
# Device helpers
# ---------------------------------------------------------------------------

def _get_devices() -> tuple[list[tuple[int, str]], list[tuple[int, str]]]:
    """Return (loopback_devices, mic_devices) as (index, label) lists."""
    loopback: list[tuple[int, str]] = []
    mic: list[tuple[int, str]] = []

    # Loopback via pyaudiowpatch
    if _HAS_PYAUDIO:
        try:
            p = _pa.PyAudio()
            for i in range(p.get_device_count()):
                d = p.get_device_info_by_index(i)
                if d.get("isLoopbackDevice"):
                    loopback.append((i, f"[{i}] {d['name']}"))
            p.terminate()
        except Exception:
            pass

    # Mic via sounddevice
    try:
        devices = sd.query_devices()
        for i, d in enumerate(devices):
            if d["max_input_channels"] > 0 and "loopback" not in d["name"].lower():
                mic.append((i, f"[{i}] {d['name']}"))
    except Exception:
        pass

    return loopback, mic


def _device_label_name(label: str) -> str:
    """Strip the leading "[N] " index prefix from a device label.

    PortAudio/sounddevice indices are just enumeration order and can shift
    between runs (e.g. a Bluetooth device reconnecting elsewhere in the
    list), so saved prefs must be matched by name, not by the index-bearing
    label string.
    """
    if label.startswith("[") and "]" in label:
        return label.split("]", 1)[1].strip()
    return label


def _current_app_environment() -> str:
    """Read appEnvironment from config/production.json (default "prod").

    Must agree with src/main.py's own resolution and with uninstall.ps1's
    Resolve-AppEnvironment, since it picks which state.json / Credential
    Manager entry this install reads and writes.
    """
    try:
        cfg = load_json_config(CONFIG_DIR / "production.json")
    except Exception:
        return "prod"
    return normalize_app_environment(cfg.get("appEnvironment"))


LEVEL_FILE = LOG_DIR / "audio_level.txt"
LEVEL_STALE_CLEAR_SECONDS = 2.0
GUI_LOCK_FILE = Path.home() / ".the-auditor" / "desktop-capture-gui.lock"
_GUI_INSTANCE_LOCK: SingleInstanceLock | None = None


# ---------------------------------------------------------------------------
# Login dialog
# ---------------------------------------------------------------------------

class _LoginDialog(tk.Toplevel):
    """Modal email + password login dialog (single window, two fields)."""

    def __init__(self, parent: tk.Misc, *, initial_email: str = "") -> None:
        super().__init__(parent)
        self.title("The Auditor ログイン")
        self.resizable(False, False)
        self.transient(parent)
        self.result: tuple[str, str] | None = None

        frame = ttk.Frame(self, padding=14)
        frame.grid(row=0, column=0)

        ttk.Label(frame, text="メールアドレス:").grid(row=0, column=0, sticky="w", pady=4)
        self._email_var = tk.StringVar(value=initial_email)
        email_entry = ttk.Entry(frame, textvariable=self._email_var, width=34)
        email_entry.grid(row=0, column=1, padx=8, pady=4)

        ttk.Label(frame, text="パスワード:").grid(row=1, column=0, sticky="w", pady=4)
        self._password_var = tk.StringVar()
        password_entry = ttk.Entry(
            frame, textvariable=self._password_var, show="*", width=34,
        )
        password_entry.grid(row=1, column=1, padx=8, pady=4)

        btn_frame = ttk.Frame(frame)
        btn_frame.grid(row=2, column=0, columnspan=2, pady=(14, 0))
        ttk.Button(btn_frame, text="ログイン", command=self._on_ok, width=12).pack(
            side="left", padx=4,
        )
        ttk.Button(btn_frame, text="キャンセル", command=self._on_cancel, width=12).pack(
            side="left", padx=4,
        )

        self.bind("<Return>", lambda _e: self._on_ok())
        self.bind("<Escape>", lambda _e: self._on_cancel())
        self.protocol("WM_DELETE_WINDOW", self._on_cancel)

        if initial_email:
            password_entry.focus_set()
        else:
            email_entry.focus_set()

        self.update_idletasks()
        try:
            self.grab_set()
        except Exception:
            pass
        self.wait_window(self)

    def _on_ok(self) -> None:
        email = self._email_var.get().strip()
        password = self._password_var.get()
        if not email or not password:
            from tkinter import messagebox
            messagebox.showerror(
                "入力エラー",
                "メールアドレスとパスワードを入力してください。",
                parent=self,
            )
            return
        self.result = (email, password)
        self.destroy()

    def _on_cancel(self) -> None:
        self.result = None
        self.destroy()


# ---------------------------------------------------------------------------
# Main window
# ---------------------------------------------------------------------------

class App(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        logger.info("GUI started")
        self.title(f"Desktop Audio Capture v{APP_VERSION}")
        self.resizable(False, False)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        self._proc: subprocess.Popen | None = None
        self._mock_procs: list[subprocess.Popen] = []
        self._log_thread: threading.Thread | None = None
        self._level_after: str | None = None
        self._next_send_time: float | None = None   # unix timestamp
        self._send_interval_s: int = 300            # default 5 min
        self._desktop_capture_identifier: str = ""
        self._scope_name: str = ""
        self._stopping = False
        self._is_compact: bool = False
        self._test_active = False
        self._test_streams: list[object] = []
        self._test_input_rms = 0
        self._test_status_var: tk.StringVar | None = None
        self._auth_env_overrides: dict[str, str] = {}
        self._checking_audit_day = False
        self._checking_overlay: tk.Frame | None = None
        self._audit_day_ready = False
        self._auth_lock = threading.RLock()
        self._lb_enabled: bool = True
        self._mic_enabled: bool = True

        try:
            LEVEL_FILE.write_text("0", encoding="utf-8")
        except Exception:
            pass

        self._build_ui()
        self._refresh_devices()
        self._update_level()
        self.after(100, self._startup_checks)

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------

    def _build_ui(self) -> None:
        self._pad = {"padx": 10, "pady": 4}
        pad = self._pad

        # --- Desktop Capture target ---
        self._audit_frame = ttk.LabelFrame(self, text="Desktop Capture")
        self._audit_frame.pack(fill="x", **pad)

        ttk.Label(self._audit_frame, text="スコープ名:").grid(row=0, column=0, sticky="w", padx=6, pady=4)
        self._scope_name_var = tk.StringVar(value="未確認")
        ttk.Label(self._audit_frame, textvariable=self._scope_name_var, foreground="#0077cc",
                  font=("", 10, "bold"), width=37).grid(row=0, column=1, sticky="w", padx=4)
        self._compact_btn = ttk.Button(self._audit_frame, text="▲", width=3,
                                       command=self._toggle_compact)
        self._compact_btn.grid(row=0, column=2, padx=(4, 6))

        ttk.Label(self._audit_frame, text="スコープUUID:").grid(row=1, column=0, sticky="w", padx=6, pady=4)
        self._scope_uuid_var = tk.StringVar(value="未設定")
        ttk.Label(self._audit_frame, textvariable=self._scope_uuid_var, foreground="#0077cc",
                  font=("", 10, "bold"), width=37).grid(row=1, column=1, sticky="w", padx=4)
        self._scope_change_btn = ttk.Button(
            self._audit_frame,
            text="変更",
            width=6,
            command=self._change_desktop_capture_identifier,
        )
        self._scope_change_btn.grid(row=1, column=2, padx=(4, 6), pady=4)

        self._audit_day_lbl = ttk.Label(self._audit_frame, text="録音セッション:")
        self._audit_day_lbl.grid(row=2, column=0, sticky="w", padx=6, pady=4)
        self._audit_day_var = tk.StringVar(value="未確認")
        self._audit_day_val_lbl = ttk.Label(self._audit_frame, textvariable=self._audit_day_var,
                                             foreground="#0077cc", font=("", 10, "bold"))
        self._audit_day_val_lbl.grid(row=2, column=1, sticky="w", padx=4)

        # --- Compact bar (shown only in compact mode) ---
        # Single row: [thin bar] [status] [next send]
        # The ▲/▼ button in audit_frame handles both minimize and restore.
        self._compact_frame = ttk.Frame(self)
        self._compact_next_label = ttk.Label(self._compact_frame, foreground="gray")
        self._compact_next_label.pack(side="right", padx=(4, 6))
        self._compact_status_label = ttk.Label(self._compact_frame, foreground="gray")
        self._compact_status_label.pack(side="right", padx=2)
        self._compact_canvas = tk.Canvas(self._compact_frame, height=7, bg="#222",
                                         highlightthickness=0)
        self._compact_canvas.pack(side="left", fill="x", expand=True, padx=(6, 4), pady=3)
        self._compact_bar = self._compact_canvas.create_rectangle(0, 0, 0, 7,
                                                                   fill="#00cc44", outline="")

        # --- Device row ---
        self._dev_frame = ttk.LabelFrame(self, text="オーディオデバイス")
        dev_frame = self._dev_frame
        dev_frame.pack(fill="x", **pad)

        ttk.Label(dev_frame, text="ループバック:").grid(row=0, column=0, sticky="w", padx=6, pady=4)
        self._lb_var = tk.StringVar()
        self._lb_combo = ttk.Combobox(dev_frame, textvariable=self._lb_var, width=38, state="readonly")
        self._lb_combo.grid(row=0, column=1, sticky="ew", padx=4)
        self._lb_toggle_btn = ttk.Button(dev_frame, text="無効にする", width=10, command=self._toggle_lb)
        self._lb_toggle_btn.grid(row=0, column=2, padx=(0, 4))

        ttk.Label(dev_frame, text="マイク:").grid(row=1, column=0, sticky="w", padx=6, pady=4)
        self._mic_var = tk.StringVar()
        self._mic_combo = ttk.Combobox(dev_frame, textvariable=self._mic_var, width=38, state="readonly")
        self._mic_combo.grid(row=1, column=1, sticky="ew", padx=4)
        self._mic_toggle_btn = ttk.Button(dev_frame, text="無効にする", width=10, command=self._toggle_mic)
        self._mic_toggle_btn.grid(row=1, column=2, padx=(0, 4))

        self._refresh_btn = ttk.Button(dev_frame, text="↺ 更新", command=self._refresh_devices)
        self._refresh_btn.grid(row=0, column=3, rowspan=2, padx=6)
        dev_frame.columnconfigure(1, weight=1)

        # --- Level meter ---
        self._meter_frame = ttk.LabelFrame(self, text="音声レベル")
        meter_frame = self._meter_frame
        meter_frame.pack(fill="x", **pad)

        self._level_canvas = tk.Canvas(meter_frame, height=20, bg="#222", highlightthickness=0)
        self._level_canvas.pack(fill="x", padx=6, pady=6)
        self._level_bar = self._level_canvas.create_rectangle(0, 0, 0, 20, fill="#00cc44", outline="")
        rms_row = ttk.Frame(meter_frame)
        rms_row.pack(fill="x", padx=6, pady=(0, 4))
        self._level_label = ttk.Label(rms_row, text="RMS: 0")
        self._level_label.pack(side="left")
        self._last_sent_var = tk.StringVar(value="最終送信: 未送信")
        ttk.Label(rms_row, textvariable=self._last_sent_var, foreground="gray").pack(side="right")
        self._next_send_var = tk.StringVar(value="次回送信: --:--:--")
        ttk.Label(rms_row, textvariable=self._next_send_var, foreground="gray").pack(side="right", padx=(0, 12))
        self._test_status_var = tk.StringVar(value="")
        ttk.Label(rms_row, textvariable=self._test_status_var, foreground="#0077cc").pack(
            side="left", padx=(12, 0)
        )

        # --- Control row ---
        self._ctrl_frame = ttk.Frame(self)
        ctrl_frame = self._ctrl_frame
        ctrl_frame.pack(fill="x", **pad)

        self._check_btn = ttk.Button(ctrl_frame, text="スコープ確認", command=self._run_audit_day_check, width=14)
        self._check_btn.pack(side="left", padx=4)
        self._start_btn = ttk.Button(ctrl_frame, text="▶ 開始", command=self._start, width=12, state="disabled")
        self._start_btn.pack(side="left", padx=4)
        self._test_btn = ttk.Button(ctrl_frame, text="▶ テスト開始", command=self._toggle_audio_test, width=14, state="disabled")
        self._test_btn.pack(side="left", padx=4)
        self._stop_btn = ttk.Button(ctrl_frame, text="■ 停止", command=self._stop,
                                    width=12, state="disabled")
        self._stop_btn.pack(side="left", padx=4)
        self._status_var = tk.StringVar(value="停止中")
        self._status_label = ttk.Label(ctrl_frame, textvariable=self._status_var, foreground="gray")
        self._status_label.pack(
            side="left", padx=8)

        self._mode_label_var = tk.StringVar(value="")
        ttk.Label(ctrl_frame, textvariable=self._mode_label_var, foreground="#888").pack(
            side="right", padx=4)

        # --- Advanced settings toggle ---
        self._adv_open = tk.BooleanVar(value=False)
        self._adv_toggle = ttk.Button(self, text="▶ 詳細設定", command=self._toggle_advanced)
        self._adv_toggle.pack(anchor="w", padx=10, pady=(6, 0))

        # --- Advanced panel (hidden by default) ---
        self._adv_frame = ttk.Frame(self)
        # (not packed yet — shown only when expanded)

        # Mode selection
        cfg_frame = ttk.LabelFrame(self._adv_frame, text="接続設定")
        cfg_frame.pack(fill="x", padx=10, pady=4)

        ttk.Label(cfg_frame, text="モード:").grid(row=0, column=0, sticky="w", padx=6, pady=4)
        self._mode = tk.StringVar(value="production")
        ttk.Radiobutton(cfg_frame, text="Production", variable=self._mode,
                        value="production").grid(row=0, column=1, sticky="w")
        ttk.Radiobutton(cfg_frame, text="Mock (ローカル)", variable=self._mode,
                        value="mock").grid(row=0, column=2, sticky="w", padx=6)

        ttk.Label(cfg_frame, text="ログレベル:").grid(row=1, column=0, sticky="w", padx=6, pady=4)
        self._verbose = tk.BooleanVar(value=False)
        ttk.Checkbutton(cfg_frame, text="詳細ログ (--verbose)", variable=self._verbose).grid(
            row=1, column=1, columnspan=2, sticky="w")

        ttk.Label(cfg_frame, text="音声保存:").grid(row=2, column=0, sticky="w", padx=6, pady=4)
        self._dump_audio = tk.BooleanVar(value=False)
        ttk.Checkbutton(cfg_frame, text="PCMファイル保存 (--dump-audio)", variable=self._dump_audio).grid(
            row=2, column=1, columnspan=2, sticky="w")

        # Log
        log_frame = ttk.LabelFrame(self._adv_frame, text="ログ")
        log_frame.pack(fill="both", expand=True, padx=10, pady=4)

        self._log = tk.Text(log_frame, height=12, width=72, state="disabled",
                            bg="#1e1e1e", fg="#d4d4d4", font=("Consolas", 9))
        scroll = ttk.Scrollbar(log_frame, command=self._log.yview)
        self._log.configure(yscrollcommand=scroll.set)
        self._log.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

    # ------------------------------------------------------------------
    # Startup checks
    # ------------------------------------------------------------------

    def _startup_checks(self) -> None:
        startup_auth = self._startup_login_if_needed()
        logger.info("Startup auth check finished: status=%s", startup_auth)
        if startup_auth in {STARTUP_AUTH_READY, STARTUP_AUTH_DEFERRED}:
            if startup_auth == STARTUP_AUTH_READY:
                self._refresh_scope_info_async()
            return
        self.destroy()

    def _startup_login_if_needed(self) -> str:
        mode = self._mode.get() if hasattr(self, "_mode") else "production"
        if mode == "mock":
            logger.info("Startup auth skipped in mock mode")
            return STARTUP_AUTH_READY

        from tkinter import messagebox

        try:
            cfg = load_json_config(CONFIG_DIR / "production.json")
        except Exception as exc:
            logger.warning("Startup auth deferred: failed to read production config: %s", exc)
            messagebox.showerror("設定エラー", f"production.json 読み込み失敗:\n{exc}", parent=self)
            return STARTUP_AUTH_DEFERRED

        the_auditor_base_url = _configured_string(cfg.get("theAuditorBaseUrl"))
        server_base_url = _configured_string(cfg.get("serverBaseUrl"))
        if not the_auditor_base_url:
            logger.warning("Startup auth deferred: theAuditorBaseUrl is not configured")
            messagebox.showerror(
                "設定エラー",
                "config/production.json の theAuditorBaseUrl が未設定です。\n\n"
                "本番環境ではThe Auditor URLを設定してください。",
                parent=self,
            )
            return STARTUP_AUTH_DEFERRED

        env = os.environ.copy()
        env.update(self._auth_env_overrides)
        env["THE_AUDITOR_BASE_URL"] = the_auditor_base_url
        if not self._prepare_auth_env(env):
            logger.info("Startup auth cancelled by user")
            return STARTUP_AUTH_CANCELLED

        try:
            self._resolve_startup_access_token(env, the_auditor_base_url, server_base_url)
            logger.info("Startup auth token resolved")
        except Exception as exc:
            logger.warning("Startup auth token resolution failed: %s", exc)
            if not (
                env.get("THE_AUDITOR_EMAIL", "").strip()
                and env.get("THE_AUDITOR_PASSWORD", "").strip()
            ):
                self._clear_persisted_auth_session()
                if not self._prepare_auth_env(env, allow_saved_auth=False):
                    logger.info("Startup login retry cancelled by user")
                    return STARTUP_AUTH_CANCELLED
                try:
                    self._login_and_save_startup_session(env, the_auditor_base_url, server_base_url)
                    logger.info("Startup login succeeded and session was saved")
                except Exception as retry_exc:
                    logger.warning("Startup login failed: %s", retry_exc)
                    self._auth_env_overrides.pop("THE_AUDITOR_EMAIL", None)
                    self._auth_env_overrides.pop("THE_AUDITOR_PASSWORD", None)
                    messagebox.showerror(
                        "ログイン失敗",
                        f"The Auditorへのログインに失敗しました。\n\n{retry_exc}",
                        parent=self,
                    )
                    return STARTUP_AUTH_CANCELLED
            else:
                logger.warning("Startup login failed with provided credentials: %s", exc)
                self._auth_env_overrides.pop("THE_AUDITOR_EMAIL", None)
                self._auth_env_overrides.pop("THE_AUDITOR_PASSWORD", None)
                messagebox.showerror("ログイン失敗", f"The Auditorへのログインに失敗しました。\n\n{exc}", parent=self)
                return STARTUP_AUTH_CANCELLED

        self._auth_env_overrides.pop("THE_AUDITOR_EMAIL", None)
        self._auth_env_overrides.pop("THE_AUDITOR_PASSWORD", None)
        return STARTUP_AUTH_READY

    def _resolve_startup_access_token(
        self,
        env: dict[str, str],
        the_auditor_base_url: str,
        server_base_url: str = "",
    ) -> str:
        sys.path.insert(0, str(ROOT))
        from src.main import _resolve_access_token
        from src.state import ClientState, default_state_path

        state_path = default_state_path(_current_app_environment())
        state = None
        if state_path.exists():
            try:
                state = ClientState.load(state_path)
            except Exception:
                state = None
        if state is None:
            state = ClientState.new(server_base_url=server_base_url)

        args = SimpleNamespace(
            mock=False,
            the_auditor_base_url=the_auditor_base_url,
        )
        env_keys = [
            "THE_AUDITOR_BASE_URL",
            "THE_AUDITOR_EMAIL",
            "THE_AUDITOR_PASSWORD",
        ]
        previous_env = {key: os.environ.get(key) for key in env_keys}
        try:
            for key in env_keys:
                value = env.get(key)
                if value:
                    os.environ[key] = value
                elif key in os.environ:
                    del os.environ[key]
            return _resolve_access_token(args, state, state_path)
        finally:
            for key, value in previous_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def _load_or_new_startup_state(self, server_base_url: str):
        sys.path.insert(0, str(ROOT))
        from src.state import ClientState, default_state_path

        state_path = default_state_path(_current_app_environment())
        state = None
        if state_path.exists():
            try:
                state = ClientState.load(state_path)
            except Exception:
                state = None
        if state is None:
            state = ClientState.new(server_base_url=server_base_url)
        return state, state_path

    def _clear_persisted_auth_session(self) -> None:
        try:
            state, state_path = self._load_or_new_startup_state("")
            state.clear_auth_session(state_path)
            state.save(state_path)
        except Exception:
            pass

    def _login_and_save_startup_session(
        self,
        env: dict[str, str],
        the_auditor_base_url: str,
        server_base_url: str,
    ) -> str:
        sys.path.insert(0, str(ROOT))
        from src.the_auditor_auth import login

        email = env.get("THE_AUDITOR_EMAIL", "").strip()
        password = env.get("THE_AUDITOR_PASSWORD", "")
        if not email or not password:
            raise RuntimeError("メールアドレスとパスワードを入力してください。")

        session = login(
            the_auditor_base_url=the_auditor_base_url,
            email=email,
            password=password,
        )
        state, state_path = self._load_or_new_startup_state(server_base_url)
        state.access_token = session.access_token
        state.refresh_token = session.refresh_token
        state.token_expires_at = session.expires_at
        if server_base_url:
            state.server_base_url = server_base_url
        state.save(state_path)
        return session.access_token

    def _has_usable_auth_state(self, env: dict[str, str]) -> bool:
        try:
            sys.path.insert(0, str(ROOT))
            from src.state import ClientState, default_state_path
            from src.the_auditor_auth import AuthSession

            state_path = default_state_path(_current_app_environment())
            if not state_path.exists():
                return False
            state = ClientState.load(state_path)
            if state.access_token and state.token_expires_at is not None:
                session = AuthSession(
                    access_token=state.access_token,
                    refresh_token=state.refresh_token or "",
                    expires_at=state.token_expires_at,
                )
                if not session.is_expired():
                    return True
            return bool(
                state.refresh_token
                and env.get("THE_AUDITOR_BASE_URL", "").strip()
            )
        except Exception:
            return False

    def _prepare_auth_env(self, env: dict[str, str], *, allow_saved_auth: bool = True) -> bool:
        env.update(self._auth_env_overrides)
        if allow_saved_auth and self._has_usable_auth_state(env):
            return True
        if env.get("THE_AUDITOR_EMAIL", "").strip() and env.get("THE_AUDITOR_PASSWORD", "").strip():
            return True

        initial_email = env.get("THE_AUDITOR_EMAIL", "").strip()
        dialog = _LoginDialog(self, initial_email=initial_email)
        if dialog.result is None:
            return False
        email, password = dialog.result

        env["THE_AUDITOR_EMAIL"] = email
        env["THE_AUDITOR_PASSWORD"] = password
        self._auth_env_overrides["THE_AUDITOR_EMAIL"] = email
        self._auth_env_overrides["THE_AUDITOR_PASSWORD"] = password
        return True

    def _resolve_access_token_blocking(self, env: dict[str, str], the_auditor_base_url: str) -> str:
        """Resolve The Auditor access token on the main thread under _auth_lock.

        Mutates os.environ briefly; restores on exit. Returns token string.
        Raises on failure (caller shows error and aborts).
        """
        with self._auth_lock:
            logger.info("_resolve_access_token_blocking: starting")
            sys.path.insert(0, str(ROOT))
            from src.main import _resolve_access_token
            from src.state import ClientState, default_state_path

            state_path = default_state_path(_current_app_environment())
            state = None
            if state_path.exists():
                try:
                    state = ClientState.load(state_path)
                except Exception:
                    state = None

            args = SimpleNamespace(
                mock=False,
                the_auditor_base_url=the_auditor_base_url,
            )
            env_keys = [
                "THE_AUDITOR_BASE_URL",
                "THE_AUDITOR_EMAIL",
                "THE_AUDITOR_PASSWORD",
            ]
            previous_env = {key: os.environ.get(key) for key in env_keys}
            try:
                for key in env_keys:
                    value = env.get(key)
                    if value:
                        os.environ[key] = value
                    elif key in os.environ:
                        del os.environ[key]
                token = _resolve_access_token(args, state, state_path)
            finally:
                for key, value in previous_env.items():
                    if value is None:
                        os.environ.pop(key, None)
                    else:
                        os.environ[key] = value
            logger.info("_resolve_access_token_blocking: done (token len=%d)", len(token or ""))
            return token

    def _load_desktop_capture_identifier(self, cfg: dict) -> str:
        identifier = _configured_string(cfg.get("desktopCaptureIdentifier"))
        if not identifier:
            raise RuntimeError("config に desktopCaptureIdentifier を設定してください。")
        mode = self._mode.get() if hasattr(self, "_mode") else "production"
        if error_message := _desktop_capture_identifier_error(identifier, mode):
            raise RuntimeError(error_message)
        self._desktop_capture_identifier = identifier
        if hasattr(self, "_scope_uuid_var"):
            self._scope_uuid_var.set(identifier)
        if hasattr(self, "_scope_name_var") and not self._scope_name:
            self._scope_name_var.set("未取得")
        return identifier

    def _current_config_path(self) -> Path:
        mode = self._mode.get() if hasattr(self, "_mode") else "production"
        cfg_name = "mock.json" if mode == "mock" else "production.json"
        return CONFIG_DIR / cfg_name

    def _read_current_config(self) -> tuple[Path, dict]:
        path = self._current_config_path()
        cfg = load_json_config(path)
        if not isinstance(cfg, dict):
            raise RuntimeError(f"{path.name} の形式が不正です。")
        return path, cfg

    def _save_desktop_capture_identifier(self, identifier: str) -> None:
        path, cfg = self._read_current_config()
        cfg["desktopCaptureIdentifier"] = identifier
        path.write_text(
            json.dumps(cfg, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )

    def _reset_scope_selection_display(self, identifier: str) -> None:
        self._desktop_capture_identifier = identifier
        self._scope_name = ""
        self._audit_day_ready = False
        if hasattr(self, "_scope_uuid_var"):
            self._scope_uuid_var.set(identifier)
        if hasattr(self, "_scope_name_var"):
            self._scope_name_var.set("未取得")
        if hasattr(self, "_audit_day_var"):
            self._audit_day_var.set("未確認")
        if getattr(self, "_proc", None) is None and not getattr(self, "_checking_audit_day", False):
            if hasattr(self, "_start_btn"):
                self._start_btn.config(state="disabled")
            if hasattr(self, "_test_btn"):
                self._test_btn.config(state="disabled")
            if hasattr(self, "_status_var"):
                self._status_var.set("スコープ未確認")

    def _change_desktop_capture_identifier(self) -> None:
        if getattr(self, "_proc", None) is not None:
            messagebox.showerror(
                "変更できません",
                "録音中はスコープUUIDを変更できません。録音を停止してから変更してください。",
                parent=self,
            )
            return
        if getattr(self, "_checking_audit_day", False):
            messagebox.showerror(
                "変更できません",
                "スコープ確認中はスコープUUIDを変更できません。確認完了後に変更してください。",
                parent=self,
            )
            return
        if getattr(self, "_test_active", False):
            messagebox.showerror(
                "変更できません",
                "音声テスト中はスコープUUIDを変更できません。テストを停止してから変更してください。",
                parent=self,
            )
            return

        current_identifier = (
            self._desktop_capture_identifier
            or (self._scope_uuid_var.get() if hasattr(self, "_scope_uuid_var") else "")
        )
        if current_identifier == "未設定":
            current_identifier = ""
        new_identifier = simpledialog.askstring(
            "スコープUUIDの変更",
            "Desktop Capture で使用するスコープUUIDを入力してください。",
            initialvalue=current_identifier,
            parent=self,
        )
        if new_identifier is None:
            return

        new_identifier = new_identifier.strip()
        if not new_identifier:
            messagebox.showerror("入力エラー", "スコープUUIDを入力してください。", parent=self)
            return
        mode = self._mode.get() if hasattr(self, "_mode") else "production"
        if error_message := _desktop_capture_identifier_error(new_identifier, mode):
            messagebox.showerror(
                "入力エラー",
                error_message,
                parent=self,
            )
            return
        if new_identifier == current_identifier:
            return

        try:
            self._save_desktop_capture_identifier(new_identifier)
        except Exception as exc:
            logger.warning("Failed to save desktopCaptureIdentifier: %s", exc)
            messagebox.showerror(
                "保存エラー",
                f"設定ファイルへの保存に失敗しました。\n{exc}",
                parent=self,
            )
            return

        self._reset_scope_selection_display(new_identifier)
        self._log_append("スコープUUIDを変更しました。スコープ情報を再取得します。\n")
        self._refresh_scope_info_async()

    def _apply_scope_display(self, status) -> None:
        scope_name = getattr(status, "scope_label", None)
        scope_uuid = (
            getattr(status, "analysis_scope_id", None)
            or getattr(status, "desktop_capture_identifier", None)
            or self._desktop_capture_identifier
        )
        if isinstance(scope_name, str) and scope_name.strip():
            self._scope_name = scope_name.strip()
            if hasattr(self, "_scope_name_var"):
                self._scope_name_var.set(self._scope_name)
        if isinstance(scope_uuid, str) and scope_uuid.strip() and hasattr(self, "_scope_uuid_var"):
            self._scope_uuid_var.set(scope_uuid.strip())

    def _fetch_scope_info_only(
        self,
        access_token: str,
        the_auditor_base_url: str,
        desktop_capture_identifier: str | None = None,
    ):
        """Thread-safe fetch of display-only scope info. Network only, no env mutation."""
        try:
            sys.path.insert(0, str(ROOT))
            from src.scope_info_api import fetch_scope_info

            logger.info("_fetch_scope_info_only: starting")
            result = fetch_scope_info(
                the_auditor_base_url=the_auditor_base_url,
                the_auditor_access_token=access_token,
                desktop_capture_identifier=desktop_capture_identifier or self._desktop_capture_identifier,
            )
            logger.info("_fetch_scope_info_only: done scope=%s", result.analysis_scope_id)
            return result
        except Exception as exc:
            return exc

    def _refresh_scope_info_async(self) -> None:
        mode = self._mode.get() if hasattr(self, "_mode") else "production"
        if mode == "mock":
            self._scope_name = "モックスコープ"
            if hasattr(self, "_scope_name_var"):
                self._scope_name_var.set("モックスコープ")
            if hasattr(self, "_scope_uuid_var"):
                self._scope_uuid_var.set(self._desktop_capture_identifier or "mock-scope-1")
            return

        try:
            cfg = load_json_config(CONFIG_DIR / "production.json")
            the_auditor_base_url = _configured_string(cfg.get("theAuditorBaseUrl"))
            desktop_capture_identifier = self._load_desktop_capture_identifier(cfg)
        except Exception as exc:
            logger.warning("Scope info refresh skipped: production config is not ready: %s", exc)
            return
        if not the_auditor_base_url:
            logger.warning("Scope info refresh skipped: theAuditorBaseUrl is not configured")
            return
        env = os.environ.copy()
        env["THE_AUDITOR_BASE_URL"] = the_auditor_base_url
        env.update(self._auth_env_overrides)
        if not (
            env.get("THE_AUDITOR_EMAIL", "").strip()
            or self._has_usable_auth_state(env)
        ):
            logger.info("Scope info refresh skipped: auth state is not ready")
            return
        try:
            access_token = self._resolve_access_token_blocking(env, the_auditor_base_url)
        except Exception as exc:
            logger.warning("Scope info refresh skipped: token resolution failed: %s", exc)
            return

        def _fetch() -> None:
            result = self._fetch_scope_info_only(
                access_token,
                the_auditor_base_url,
                desktop_capture_identifier,
            )
            if isinstance(result, Exception):
                logger.warning("Scope info refresh failed: %s", result)
                return
            self._call_on_ui_thread(self._apply_scope_display, result)

        threading.Thread(target=_fetch, daemon=True).start()

    def _fetch_scope_readiness_only(
        self,
        access_token: str,
        the_auditor_base_url: str,
        desktop_capture_identifier: str | None = None,
    ):
        """Thread-safe fetch of scope readiness. Network only, no env mutation.

        Returns ScopeReadiness or Exception (never raises).
        """
        try:
            sys.path.insert(0, str(ROOT))
            from src.scope_readiness_api import ScopeReadinessError, fetch_scope_readiness

            logger.info("_fetch_scope_readiness_only: starting")
            result = fetch_scope_readiness(
                the_auditor_base_url=the_auditor_base_url,
                the_auditor_access_token=access_token,
                desktop_capture_identifier=desktop_capture_identifier or self._desktop_capture_identifier,
            )
            logger.info("_fetch_scope_readiness_only: done ready=%s", result.ready)
            return result
        except ScopeReadinessError as exc:
            return exc
        except Exception as exc:
            logger.warning("_fetch_scope_readiness_only: caught: %s", exc)
            return RuntimeError("スコープ状態の確認に失敗しました。通信設定を確認してください。")

    @staticmethod
    def _parse_boundary_time(value: str | None):
        from datetime import time as dt_time

        if not value:
            return dt_time(0, 0, 0)
        parts = value.split(":")
        try:
            hour = int(parts[0])
            minute = int(parts[1]) if len(parts) > 1 else 0
            second = int(parts[2]) if len(parts) > 2 else 0
            return dt_time(hour, minute, second)
        except Exception:
            return dt_time(0, 0, 0)

    @classmethod
    def _business_date(cls, dt, boundary):
        from datetime import timedelta

        business_date = dt.date()
        if dt.time() < boundary:
            business_date = business_date - timedelta(days=1)
        return business_date

    @classmethod
    def _is_stale_audit_day(cls, status, now=None) -> bool:
        if (
            status is None
            or not status.ready
            or not status.started_at
            or not status.business_timezone
        ):
            return False
        from datetime import datetime
        from zoneinfo import ZoneInfo

        started_at = datetime.fromisoformat(status.started_at.replace("Z", "+00:00"))
        timezone = ZoneInfo(status.business_timezone)
        business_now = now.astimezone(timezone) if now is not None else datetime.now(timezone)
        boundary = cls._parse_boundary_time(
            getattr(status, "business_day_boundary_local_time", None)
        )
        return cls._business_date(started_at.astimezone(timezone), boundary) < cls._business_date(
            business_now,
            boundary,
        )

# ------------------------------------------------------------------
    # Compact / full toggle
    # ------------------------------------------------------------------

    def _toggle_compact(self) -> None:
        if self._is_compact:
            # Restore full view
            self._audit_day_lbl.grid(row=2, column=0, sticky="w", padx=6, pady=4)
            self._audit_day_val_lbl.grid(row=2, column=1, sticky="w", padx=4)
            self._compact_frame.pack_forget()
            self._dev_frame.pack(fill="x", **self._pad)
            self._meter_frame.pack(fill="x", **self._pad)
            self._ctrl_frame.pack(fill="x", **self._pad)
            self._adv_toggle.pack(anchor="w", padx=10, pady=(6, 0))
            if self._adv_open.get():
                self._adv_frame.pack(fill="both", expand=True)
            self._compact_btn.config(text="▲")
            self._is_compact = False
        else:
            # Collapse to compact bar
            self._audit_day_lbl.grid_remove()
            self._audit_day_val_lbl.grid_remove()
            self._adv_frame.pack_forget()
            self._adv_toggle.pack_forget()
            self._ctrl_frame.pack_forget()
            self._meter_frame.pack_forget()
            self._dev_frame.pack_forget()
            self._compact_frame.pack(fill="x", **self._pad)
            self._compact_btn.config(text="▼")
            self._is_compact = True
        self.update_idletasks()
        self.geometry("")   # let tk shrink/grow to fit content

    # Advanced settings toggle
    # ------------------------------------------------------------------

    def _toggle_advanced(self) -> None:
        if self._adv_open.get():
            self._adv_frame.pack_forget()
            self._adv_open.set(False)
            self._adv_toggle.config(text="▶ 詳細設定")
            self.resizable(False, False)
        else:
            self._adv_frame.pack(fill="both", expand=True)
            self._adv_open.set(True)
            self._adv_toggle.config(text="▼ 詳細設定")
            self.resizable(True, True)

    # ------------------------------------------------------------------
    # Device enable/disable toggles
    # ------------------------------------------------------------------

    def _toggle_lb(self) -> None:
        self._lb_enabled = not self._lb_enabled
        self._update_device_toggle_states()

    def _toggle_mic(self) -> None:
        self._mic_enabled = not self._mic_enabled
        self._update_device_toggle_states()

    def _update_device_toggle_states(self) -> None:
        lb_en = self._lb_enabled
        mic_en = self._mic_enabled
        lb_btn = getattr(self, "_lb_toggle_btn", None)
        mic_btn = getattr(self, "_mic_toggle_btn", None)
        lb_combo = getattr(self, "_lb_combo", None)
        mic_combo = getattr(self, "_mic_combo", None)

        if lb_btn:
            lb_btn.config(text="有効にする" if not lb_en else "無効にする")
        if mic_btn:
            mic_btn.config(text="有効にする" if not mic_en else "無効にする")
        if lb_combo:
            lb_combo.config(state="readonly" if lb_en else "disabled")
        if mic_combo:
            mic_combo.config(state="readonly" if mic_en else "disabled")

        if lb_btn and mic_btn:
            if not lb_en:
                lb_btn.config(state="normal")
                mic_btn.config(state="disabled")
            elif not mic_en:
                lb_btn.config(state="disabled")
                mic_btn.config(state="normal")
            else:
                lb_btn.config(state="normal")
                mic_btn.config(state="normal")

    # ------------------------------------------------------------------
    # Device refresh
    # ------------------------------------------------------------------

    def _refresh_devices(self) -> None:
        if getattr(self, "_checking_audit_day", False):
            return
        if self._proc is not None:  # recording in progress — don't change device list
            return
        lb_devs, mic_devs = _get_devices()

        self._lb_indices = [idx for idx, _ in lb_devs]
        self._lb_combo["values"] = [label for _, label in lb_devs]
        if lb_devs:
            self._lb_combo.current(0)

        self._mic_indices = [idx for idx, _ in mic_devs]
        self._mic_combo["values"] = [label for _, label in mic_devs]
        # Select default mic
        try:
            default_in = sd.default.device[0]
            for i, idx in enumerate(self._mic_indices):
                if idx == default_in:
                    self._mic_combo.current(i)
                    break
            else:
                if mic_devs:
                    self._mic_combo.current(0)
        except Exception:
            if mic_devs:
                self._mic_combo.current(0)

        try:
            prefs = json.loads(_GUI_PREFS_PATH.read_text(encoding="utf-8"))
            saved_lb = prefs.get("loopback_device_label")
            saved_mic = prefs.get("mic_device_label")
            if saved_lb:
                lb_labels = list(self._lb_combo["values"])
                if saved_lb in lb_labels:
                    self._lb_combo.current(lb_labels.index(saved_lb))
                else:
                    saved_lb_name = _device_label_name(saved_lb)
                    for i, label in enumerate(lb_labels):
                        if _device_label_name(label) == saved_lb_name:
                            self._lb_combo.current(i)
                            break
            if saved_mic:
                mic_labels = list(self._mic_combo["values"])
                if saved_mic in mic_labels:
                    self._mic_combo.current(mic_labels.index(saved_mic))
                else:
                    saved_mic_name = _device_label_name(saved_mic)
                    for i, label in enumerate(mic_labels):
                        if _device_label_name(label) == saved_mic_name:
                            self._mic_combo.current(i)
                            break
        except Exception:
            pass

    def _save_device_prefs(self) -> None:
        prefs = {
            "loopback_device_label": self._lb_var.get() if self._lb_enabled else None,
            "mic_device_label": self._mic_var.get() if self._mic_enabled else None,
        }
        try:
            _GUI_PREFS_PATH.parent.mkdir(parents=True, exist_ok=True)
            _GUI_PREFS_PATH.write_text(json.dumps(prefs), encoding="utf-8")
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Start / Stop
    # ------------------------------------------------------------------

    def _start(self) -> None:
        if getattr(self, "_checking_audit_day", False):
            logger.info("Start ignored: scope readiness check is running")
            return
        if self._test_active:
            logger.warning("Capture start blocked: audio test is active")
            self._log_append("ERROR: 音声テスト中は録音を開始できません。テスト終了後に開始してください。\n")
            return

        lb_sel = self._lb_combo.current()
        mic_sel = self._mic_combo.current()
        lb_enabled = self._lb_enabled
        mic_enabled = self._mic_enabled

        if lb_enabled and lb_sel < 0:
            logger.warning("Capture start blocked: loopback device selection missing")
            self._log_append("ERROR: ループバックデバイスを選択してください\n")
            return
        if mic_enabled and mic_sel < 0:
            logger.warning("Capture start blocked: mic device selection missing")
            self._log_append("ERROR: マイクデバイスを選択してください\n")
            return

        lb_idx = self._lb_indices[lb_sel] if lb_enabled and lb_sel >= 0 else None
        mic_idx = self._mic_indices[mic_sel] if mic_enabled and mic_sel >= 0 else None
        mode = self._mode.get()

        # Production: check server URL is configured
        if mode == "production":
            try:
                cfg = load_json_config(CONFIG_DIR / "production.json")
                url = _configured_string(cfg.get("serverBaseUrl"))
                if not url:
                    from tkinter import messagebox
                    messagebox.showerror(
                        "設定エラー",
                        "config/production.json の serverBaseUrl が未設定です。\n\n"
                        "・Mockで動作確認する場合は「詳細設定」でMockを選択してください。\n"
                        "・本番環境を使う場合はAWS側の音声API URLを設定してください。"
                    )
                    return
                if not _configured_string(cfg.get("theAuditorBaseUrl")):
                    from tkinter import messagebox
                    messagebox.showerror(
                        "設定エラー",
                        "config/production.json の theAuditorBaseUrl が未設定です。\n\n"
                        "本番環境ではThe Auditor URLを設定してください。",
                    )
                    return
                try:
                    self._load_desktop_capture_identifier(cfg)
                except RuntimeError as exc:
                    from tkinter import messagebox
                    messagebox.showerror("設定エラー", str(exc), parent=self)
                    return
            except Exception as exc:
                from tkinter import messagebox
                messagebox.showerror("設定エラー", f"production.json 読み込み失敗:\n{exc}")
                return

        # Read send interval from config
        try:
            cfg_name = "mock.json" if mode == "mock" else "production.json"
            _cfg = load_json_config(CONFIG_DIR / cfg_name)
            self._send_interval_s = int(_cfg.get("sendIntervalMinutes", 5)) * 60
            desktop_capture_identifier = self._load_desktop_capture_identifier(_cfg)
        except Exception:
            self._send_interval_s = 300
            desktop_capture_identifier = self._desktop_capture_identifier

        # Mock mode: start servers if not already running
        if mode == "mock":
            self._ensure_mock_servers()

        # Map pyaudio loopback index → sounddevice WASAPI output index
        sd_lb_idx = self._resolve_sd_loopback_index(lb_idx) if lb_idx is not None else None

        cmd = [sys.executable, "-m", "src.main"]
        if self._verbose.get():
            cmd.append("--verbose")
        if self._dump_audio.get():
            cmd.append("--dump-audio")
        if mode == "mock":
            cmd.append("--mock")
        else:
            cmd += ["--config", str(CONFIG_DIR / "production.json")]

        self._mode_label_var.set(f"[{mode}]")

        if desktop_capture_identifier:
            cmd += ["--desktop-capture-identifier", desktop_capture_identifier]

        if sd_lb_idx is not None:
            cmd += ["--loopback-device", str(sd_lb_idx)]
        if mic_idx is not None:
            cmd += ["--mic-device", str(mic_idx)]

        self._log_append(f"起動: {' '.join(cmd)}\n")
        logger.info(
            "Capture start requested: mode=%s loopback_pyaudio_device=%s "
            "loopback_sd_device=%s mic_device=%s send_interval_sec=%s verbose=%s dump_audio=%s",
            mode,
            lb_idx,
            sd_lb_idx,
            mic_idx,
            self._send_interval_s,
            bool(self._verbose.get()),
            bool(self._dump_audio.get()),
        )

        env = os.environ.copy()
        env["PYTHONIOENCODING"] = "utf-8"
        if mode != "mock":
            the_auditor_base_url = _configured_string(_cfg.get("theAuditorBaseUrl")) or url
            env["THE_AUDITOR_BASE_URL"] = the_auditor_base_url
        if mode != "mock" and not self._prepare_auth_env(env):
            return
        self._save_device_prefs()
        self._start_capture_process(cmd, env)

    def _run_audit_day_check(self) -> None:
        if getattr(self, "_checking_audit_day", False):
            return
        if self._proc is not None:
            return

        mode = self._mode.get()
        if mode == "mock":
            self._audit_day_ready = True
            self._start_btn.config(state="normal")
            self._test_btn.config(state="normal")
            self._status_var.set("スコープ確認済み")
            self._scope_name = "モックスコープ"
            if hasattr(self, "_scope_name_var"):
                self._scope_name_var.set("モックスコープ")
            if hasattr(self, "_scope_uuid_var"):
                self._scope_uuid_var.set(self._desktop_capture_identifier or "mock-scope-1")
            self._audit_day_var.set("モックセッション")
            logger.info("Scope readiness check skipped in mock mode: capture buttons enabled")
            return

        try:
            cfg = load_json_config(CONFIG_DIR / "production.json")
            the_auditor_base_url = _configured_string(cfg.get("theAuditorBaseUrl"))
            desktop_capture_identifier = self._load_desktop_capture_identifier(cfg)
            if not the_auditor_base_url:
                messagebox.showerror(
                    "設定エラー",
                    "config/production.json の theAuditorBaseUrl が未設定です。",
                    parent=self,
                )
                return
        except Exception as exc:
            messagebox.showerror("設定エラー", f"production.json 読み込み失敗:\n{exc}", parent=self)
            return

        env = os.environ.copy()
        env["THE_AUDITOR_BASE_URL"] = the_auditor_base_url
        if not self._prepare_auth_env(env):
            return

        # Step 1 (HIGHEST PRIORITY): resolve token on main thread BEFORE doing
        # anything else. If this fails, do not show the overlay at all.
        try:
            access_token = self._resolve_access_token_blocking(env, the_auditor_base_url)
        except Exception as exc:
            logger.warning("Scope readiness check aborted: token resolution failed: %s", exc)
            messagebox.showerror(
                "スコープ確認失敗",
                "認証に失敗しました。アプリを再起動してログインし直してください。",
                parent=self,
            )
            return

        # Step 2: start the thread FIRST so the network call begins immediately
        # and is never blocked by overlay creation issues.
        result_queue: queue.Queue = queue.Queue()

        def _check() -> None:
            logger.info("Scope readiness check thread started")
            try:
                status = self._fetch_scope_readiness_only(
                    access_token,
                    the_auditor_base_url,
                    desktop_capture_identifier,
                )
            except BaseException as exc:
                logger.exception("Scope readiness check thread: unexpected error")
                status = RuntimeError(str(exc))
            logger.info("Scope readiness check thread: putting result")
            result_queue.put(status)

        def _poll() -> None:
            try:
                status = result_queue.get_nowait()
            except queue.Empty:
                if hasattr(self, "_w"):
                    self.after(100, _poll)
                return
            self._finish_audit_day_check_standalone(status)

        threading.Thread(target=_check, daemon=True).start()

        # Step 3: best-effort overlay/UI lock. If this throws, we still want
        # the poll loop to drain the queue and call _finish_*.
        try:
            self._set_checking(True)
        except Exception:
            logger.exception("_set_checking(True) failed; proceeding without overlay")
            self._checking_audit_day = True  # still block re-entry

        if hasattr(self, "_w"):
            self.after(100, _poll)
        else:
            self._finish_audit_day_check_standalone(result_queue.get())

    def _finish_audit_day_check_standalone(self, audit_day_status) -> None:
        self._set_checking(False)
        if isinstance(audit_day_status, Exception):
            if getattr(audit_day_status, "is_auth_failure", False):
                message = "認証に失敗しました。アプリを再起動してログインし直してください。"
            else:
                message = "スコープの確認に失敗しました。ネットワーク接続と識別子を確認してから再度お試しください。"
            logger.warning("Scope readiness check failed: %s", audit_day_status)
            self._audit_day_var.set("確認失敗")
            messagebox.showerror("スコープ確認失敗", message, parent=self)
            return
        logger.info(
            "Scope readiness status: ready=%s analysis_scope_id=%s audit_plan_session_id=%s blocker=%s",
            audit_day_status.ready,
            getattr(audit_day_status, "analysis_scope_id", None),
            getattr(audit_day_status, "audit_plan_session_id", None),
            getattr(audit_day_status, "blocker", None),
        )
        if not audit_day_status.ready:
            blocker = getattr(audit_day_status, "blocker", None)
            message = "同じスコープで録音またはテキスト解析が進行中です。完了後に再度確認してください。"
            logger.warning("Scope readiness check blocked: %s blocker=%s", message, blocker)
            self._audit_day_var.set("待機中")
            messagebox.showerror("スコープ未準備", message, parent=self)
            return
        self._apply_scope_display(audit_day_status)
        self._audit_day_ready = True
        self._start_btn.config(state="normal")
        self._test_btn.config(state="normal")
        self._status_var.set("スコープ確認済み")
        self._audit_day_var.set(format_scope_readiness_display_name(audit_day_status))
        logger.info("Scope readiness check passed: capture buttons enabled")

    def _call_on_ui_thread(self, func, *args) -> None:
        after = getattr(self, "after", None)
        if hasattr(self, "_w") and callable(after):
            after(0, func, *args)
        else:
            func(*args)

    def _start_capture_process(self, cmd: list[str], env: dict[str, str]) -> None:
        # Use python.exe (not pythonw.exe) so the subprocess has a console
        # and can receive CTRL_BREAK_EVENT for graceful shutdown.
        # CREATE_NO_WINDOW hides the console window.
        python_exe = sys.executable.replace("pythonw.exe", "python.exe")
        cmd[0] = python_exe

        try:
            self._proc = subprocess.Popen(
                cmd,
                cwd=str(ROOT),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                env=env,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW,
            )
        except Exception as exc:
            logger.exception("Failed to start capture process")
            self._log_append(f"ERROR: {exc}\n")
            self._set_running(False)
            self._status_var.set("停止中")
            return

        logger.info("Capture process started: pid=%s", self._proc.pid)

        self._set_running(True)
        self._status_var.set("接続中...")
        self._next_send_time = time.time() + self._send_interval_s

        self._log_thread = threading.Thread(target=self._tail_log, daemon=True)
        self._log_thread.start()


    def _resolve_sd_loopback_index(self, pyaudio_loopback_idx: int) -> int | None:
        """Find the sounddevice output device index matching the pyaudio loopback.

        Prefers WASAPI host API devices over MME/DirectSound to ensure the
        correct high-quality device is selected (e.g. index 16 not 3).
        """
        if not _HAS_PYAUDIO:
            return None
        try:
            p = _pa.PyAudio()
            dev = p.get_device_info_by_index(pyaudio_loopback_idx)
            name: str = dev["name"]
            p.terminate()

            # Strip " [Loopback]" suffix and match against sd devices
            base = name.replace(" [Loopback]", "").strip()
            devices = sd.query_devices()
            host_apis = sd.query_hostapis()

            # First pass: prefer WASAPI
            for i, d in enumerate(devices):
                if d["max_output_channels"] > 0 and base in d["name"]:
                    api_name = host_apis[d["hostapi"]]["name"] if d["hostapi"] < len(host_apis) else ""
                    if "WASAPI" in api_name:
                        return i

            # Second pass: any matching output device
            for i, d in enumerate(devices):
                if d["max_output_channels"] > 0 and base in d["name"]:
                    return i
        except Exception:
            pass
        # Fallback: use sounddevice default output
        try:
            return sd.default.device[1]
        except Exception:
            return None

    def _ensure_mock_servers(self) -> None:
        """Start mock API and WS servers if not already listening."""
        import socket

        scripts = [
            (MOCK_API_PORT, ROOT / "verification" / "mock_api_server.py"),
        ]
        started_any = False
        for port, script in scripts:
            sock = socket.socket()
            sock.settimeout(0.3)
            try:
                sock.connect(("127.0.0.1", port))
                sock.close()
                # Already listening — nothing to do
            except OSError:
                sock.close()
                self._log_append(f"Mock server起動中 (port {port})…\n")
                LOG_DIR.mkdir(parents=True, exist_ok=True)
                log_path = LOG_DIR / f"mock_server_{port}.log"
                log_f = open(log_path, "w", encoding="utf-8")
                try:
                    p = subprocess.Popen(
                        [sys.executable, str(script)],
                        cwd=str(ROOT),
                        stdout=log_f,
                        stderr=subprocess.STDOUT,
                    )
                finally:
                    log_f.close()
                self._mock_procs.append(p)
                started_any = True

        if started_any:
            time.sleep(1.5)  # wait for servers to bind

    def _set_running(self, running: bool) -> None:
        """Central place to flip button states."""
        audit_ready = getattr(self, "_audit_day_ready", False)
        check_btn = getattr(self, "_check_btn", None)
        if running:
            self._start_btn.config(state="disabled")
            self._test_btn.config(state="disabled")
            self._stop_btn.config(state="normal")
            if check_btn:
                check_btn.config(state="disabled")
            for attr in ("_lb_combo", "_mic_combo", "_refresh_btn", "_scope_change_btn",
                         "_lb_toggle_btn", "_mic_toggle_btn"):
                w = getattr(self, attr, None)
                if w:
                    w.config(state="disabled")
        else:
            self._start_btn.config(state="normal" if audit_ready else "disabled")
            self._test_btn.config(state="normal" if audit_ready else "disabled")
            self._stop_btn.config(state="disabled")
            if check_btn:
                check_btn.config(state="normal")
            for attr in ("_refresh_btn", "_scope_change_btn"):
                w = getattr(self, attr, None)
                if w:
                    w.config(state="normal")
            self._update_device_toggle_states()

    def _set_checking(self, checking: bool) -> None:
        def _config(name: str, **kwargs) -> None:
            widget = getattr(self, name, None)
            if widget is not None:
                widget.config(**kwargs)

        if checking:
            self._checking_audit_day = True
            self._start_btn.config(state="disabled")
            self._test_btn.config(state="disabled")
            self._stop_btn.config(state="disabled")
            _config("_check_btn", state="disabled")
            _config("_lb_combo", state="disabled")
            _config("_mic_combo", state="disabled")
            _config("_lb_toggle_btn", state="disabled")
            _config("_mic_toggle_btn", state="disabled")
            _config("_refresh_btn", state="disabled")
            _config("_scope_change_btn", state="disabled")
            _config("_adv_toggle", state="disabled")
            _config("_status_label", foreground="#cc7a00")
            self._status_var.set("スコープ確認中... 操作できません")
            self._log_append("スコープ確認中...\n")
            logger.info("Scope readiness check started")
            try:
                self._show_checking_overlay()
            except Exception:
                logger.exception("_show_checking_overlay failed; continuing without overlay")
            try:
                update_idletasks = getattr(self, "update_idletasks", None)
                if callable(update_idletasks):
                    update_idletasks()
            except Exception:
                logger.exception("update_idletasks failed; continuing")
        else:
            self._checking_audit_day = False
            self._close_checking_overlay()
            audit_ready = getattr(self, "_audit_day_ready", False)
            self._start_btn.config(state="normal" if audit_ready else "disabled")
            self._test_btn.config(state="normal" if audit_ready else "disabled")
            self._stop_btn.config(state="disabled")
            _config("_check_btn", state="normal")
            _config("_refresh_btn", state="normal")
            _config("_scope_change_btn", state="normal")
            _config("_adv_toggle", state="normal")
            _config("_status_label", foreground="gray")
            self._status_var.set("停止中")
            self._update_device_toggle_states()
            logger.info("Scope readiness check finished")

    def _show_checking_overlay(self) -> None:
        if getattr(self, "_checking_overlay", None) is not None:
            return
        if not hasattr(self, "_w"):
            return
        logger.info("_show_checking_overlay: creating frame")
        overlay = tk.Frame(self, bg="#f2f2f2", highlightthickness=2, highlightbackground="#cc7a00")
        logger.info("_show_checking_overlay: creating panel")
        panel = tk.Frame(overlay, bg="#ffffff", bd=1, relief="solid")
        panel.place(relx=0.5, rely=0.5, anchor="center")
        tk.Label(
            panel,
            text="スコープ確認中",
            bg="#ffffff",
            fg="#222222",
            font=("", 12, "bold"),
            padx=28,
            pady=18,
        ).pack(pady=(0, 4))
        tk.Label(
            panel,
            text="完了するまで操作できません。",
            bg="#ffffff",
            fg="#444444",
            padx=28,
        ).pack(pady=(0, 18))
        logger.info("_show_checking_overlay: placing overlay")
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        overlay.lift()
        self._checking_overlay = overlay
        logger.info("Scope readiness checking overlay shown")

    def _close_checking_overlay(self) -> None:
        overlay = getattr(self, "_checking_overlay", None)
        self._checking_overlay = None
        if overlay is None:
            return
        try:
            overlay.destroy()
        except Exception:
            pass
        logger.info("Scope readiness checking overlay closed")

    def _stop(self) -> None:
        if getattr(self, "_checking_audit_day", False):
            logger.info("Stop ignored: scope readiness check is running")
            return
        proc = self._proc
        if proc is None:
            logger.info("Stop requested: no capture process is running")
            self._set_running(False)
            self._status_var.set("停止中")
            return

        if proc.poll() is not None:
            logger.info("Stop requested: capture process already ended rc=%s", proc.returncode)
            self._on_proc_ended(proc.returncode or 0)
            return

        logger.info("Stop button pressed: pid=%s — showing confirmation dialog", proc.pid)
        if not messagebox.askyesno(
            "停止確認",
            "本当に停止してよろしいですか？",
            parent=self,
        ):
            logger.info("Stop cancelled by user: pid=%s", proc.pid)
            return
        logger.info("Stop confirmed by user: pid=%s", proc.pid)
        self._stopping = True
        self._start_btn.config(state="disabled")
        self._test_btn.config(state="disabled")
        self._stop_btn.config(state="disabled")
        self._status_var.set("停止処理中...")
        self._next_send_var.set("次回送信: --:--:--")
        self._next_send_time = None
        try:
            # Graceful shutdown: write stop file, subprocess flushes then exits.
            (Path.home() / ".the-auditor" / "stop_request").touch()

            def _force_kill():
                try:
                    if proc.poll() is None:
                        logger.warning("Capture process did not stop gracefully; terminating pid=%s", proc.pid)
                        proc.terminate()
                except Exception:
                    pass

            threading.Timer(15.0, _force_kill).start()
        except Exception:
            logger.exception("Failed to request graceful stop; terminating capture process")
            proc.terminate()
        try:
            LEVEL_FILE.write_text("0", encoding="utf-8")
        except Exception:
            pass
        self._log_append("--- 停止 ---\n")

    # ------------------------------------------------------------------
    # Audio test
    # ------------------------------------------------------------------

    def _toggle_audio_test(self) -> None:
        if getattr(self, "_checking_audit_day", False):
            logger.info("Audio test toggle ignored: scope readiness check is running")
            return
        if self._test_active:
            self._stop_audio_test()
        else:
            self._start_audio_test()

    def _start_audio_test(self) -> None:
        if self._proc is not None:
            logger.warning("Audio test start blocked: capture is running")
            self._log_append("ERROR: 録音中は音声テストを開始できません。停止後にテストしてください。\n")
            return

        lb_sel = self._lb_combo.current()
        mic_sel = self._mic_combo.current()
        lb_enabled = self._lb_enabled
        mic_enabled = self._mic_enabled

        loopback_device_idx = None
        if lb_enabled and lb_sel >= 0:
            lb_idx = self._lb_indices[lb_sel]
            loopback_device_idx = self._resolve_sd_loopback_index(lb_idx)

        mic_idx = self._mic_indices[mic_sel] if (mic_enabled and mic_sel >= 0) else None

        self._test_active = True
        self._test_input_rms = 0
        self._test_streams = []
        self._test_btn.config(text="■ テスト終了")
        self._start_btn.config(state="disabled")
        self._stop_btn.config(state="disabled")
        self._status_var.set("音声テスト中")
        if self._test_status_var is not None:
            self._test_status_var.set("テスト中: 入力 0")

        if loopback_device_idx is not None or mic_idx is not None:
            try:
                sys.path.insert(0, str(ROOT))
                from src.audio_mixer import AudioMixer

                mixer = AudioMixer(
                    loopback_device=loopback_device_idx,
                    mic_device=mic_idx,
                    on_frame=self._on_test_audio_frame,
                )
                mixer.start()
                self._test_streams.append(mixer)
                logger.info(
                    "Audio test input monitor started: loopback_device=%s mic_device=%s",
                    loopback_device_idx,
                    mic_idx,
                )
                self._log_append("音声テスト: 入力/ループバック監視を開始しました\n")
            except Exception as exc:
                logger.warning("Audio test input monitor failed: %s", exc)
                self._log_append(f"WARNING: 入力テスト開始に失敗しました: {exc}\n")

        if not self._test_streams:
            self._stop_audio_test()
            logger.error("Audio test could not start: no streams opened")
            self._log_append("ERROR: 音声テストを開始できませんでした\n")

    @staticmethod
    def _default_output_device_index() -> int | None:
        try:
            idx = sd.default.device[1]
            if idx is not None and idx >= 0:
                return int(idx)
        except Exception:
            pass
        return None

    def _stop_audio_test(self) -> None:
        for stream in self._test_streams:
            try:
                if hasattr(stream, "stop"):
                    stream.stop()
            except Exception:
                pass
            try:
                if hasattr(stream, "close"):
                    stream.close()
            except Exception:
                pass

        self._test_streams = []
        self._test_active = False
        self._test_input_rms = 0
        self._test_btn.config(text="▶ テスト開始")
        if self._proc is None:
            audit_ready = getattr(self, "_audit_day_ready", False)
            self._start_btn.config(state="normal" if audit_ready else "disabled")
            self._stop_btn.config(state="disabled")
            self._status_var.set("停止中")
        if self._test_status_var is not None:
            self._test_status_var.set("")
        logger.info("Audio test stopped")
        self._log_append("音声テスト: 停止しました\n")

    def _on_test_audio_frame(self, pcm_bytes: bytes) -> None:
        self._test_input_rms = self._rms_from_pcm16_bytes(pcm_bytes)

    @staticmethod
    def _rms_from_pcm16_bytes(pcm_bytes: bytes) -> int:
        if not pcm_bytes:
            return 0
        count = len(pcm_bytes) // 2
        if count <= 0:
            return 0
        total = 0
        for i in range(0, count * 2, 2):
            sample = int.from_bytes(pcm_bytes[i:i + 2], "little", signed=True)
            total += sample * sample
        return int(math.sqrt(total / count))

    # ------------------------------------------------------------------
    # Log tail (runs in thread)
    # ------------------------------------------------------------------

    def _tail_log(self) -> None:
        proc = self._proc
        if proc is None:
            return
        streaming_seen = False
        fatal_auth_seen = False
        for line in proc.stdout:
            self.after(0, self._log_append, line)
            if "Uploading audio chunks" in line and not streaming_seen:
                streaming_seen = True
                self.after(0, self._status_var.set, "録音中 ●")
            if not streaming_seen and ("Error" in line or "error" in line):
                self.after(0, self._status_var.set, "エラー")
            # Match the upload_audio_chunk confirmation line (contains jobId=).
            # This line is logged exactly once per confirmed successful upload.
            if "Audio sent" in line and "jobId=" in line:
                ts = line.split()[0] if line else ""
                self.after(0, self._last_sent_var.set, f"最終送信: {ts}")
                self.after(0, self._advance_next_send_time)
            if "FATAL_AUTH_ERROR:" in line and not fatal_auth_seen:
                fatal_auth_seen = True
                self.after(0, self._on_fatal_auth_error)
        rc = proc.wait()
        self.after(0, self._on_proc_ended, rc)

    def _on_fatal_auth_error(self) -> None:
        from tkinter import messagebox
        self._status_var.set("認証エラー")
        messagebox.showerror(
            "認証エラー",
            "The Auditor への認証が失効しました。\n\n"
            "録音を再開するには「スコープ確認」を押してください。",
            parent=self,
        )

    def _on_proc_ended(self, rc: int) -> None:
        if self._proc is None:
            return
        proc = self._proc
        self._proc = None  # clear first to make subsequent calls no-ops
        logger.info("Capture process ended: pid=%s rc=%s stopping=%s", proc.pid, rc, self._stopping)
        was_stopping = self._stopping
        self._stopping = False
        if not self._test_active:
            self._set_running(False)
        if was_stopping or rc == 0 or rc == -15:   # 0=clean, -15=SIGTERM from _stop()
            self._status_var.set("停止中")
        else:
            self._status_var.set(f"終了 (rc={rc})")
            self._next_send_var.set("次回送信: --:--:--")
            self._next_send_time = None
            logger.warning("Capture process ended unexpectedly: rc=%s", rc)
            messagebox.showwarning(
                "録音プロセス停止",
                "バックグラウンドの録音プロセスが予期せず停止しました。\n\n"
                f"終了コード: {rc}\n"
                f"ログ: {LOG_DIR / 'desktop-capture.log'}\n"
                f"クラッシュ診断: {LOG_DIR / 'desktop-capture-fault.log'}",
                parent=self,
            )

    # ------------------------------------------------------------------
    # Audio level meter
    # ------------------------------------------------------------------

    def _advance_next_send_time(self) -> None:
        if self._next_send_time is not None:
            self._next_send_time += self._send_interval_s

    def _update_level(self) -> None:
        rms = 0
        if self._test_active:
            rms = self._test_input_rms
            if self._test_status_var is not None:
                self._test_status_var.set(f"テスト中: 入力 {self._test_input_rms}")
        else:
            try:
                if LEVEL_FILE.exists():
                    if time.time() - LEVEL_FILE.stat().st_mtime <= LEVEL_STALE_CLEAR_SECONDS:
                        rms = int(LEVEL_FILE.read_text(encoding="utf-8").strip())
            except Exception:
                pass

        # Update bar
        if self._test_active:
            color = "#3388ff" if rms < 800 else "#00cc88" if rms < 8000 else "#ffcc00" if rms < 24000 else "#ff4444"
        else:
            color = "#00cc44" if rms < 8000 else "#ffcc00" if rms < 24000 else "#ff4444"

        w = self._level_canvas.winfo_width()
        if w > 1:
            fill = min(int(rms / 32767 * w * 8), w)
            self._level_canvas.coords(self._level_bar, 0, 0, fill, 20)
            self._level_canvas.itemconfig(self._level_bar, fill=color)
        self._level_label.config(text=f"{'TEST ' if self._test_active else ''}RMS: {rms}")

        # Update compact bar
        cw = self._compact_canvas.winfo_width()
        if cw > 1:
            cfill = min(int(rms / 32767 * cw * 8), cw)
            self._compact_canvas.coords(self._compact_bar, 0, 0, cfill, 7)
            self._compact_canvas.itemconfig(self._compact_bar, fill=color)
        self._compact_status_label.config(text=self._status_var.get())

        # Update next send label
        if self._next_send_time is not None:
            next_str = "次回送信: " + time.strftime("%H:%M:%S", time.localtime(self._next_send_time))
            self._next_send_var.set(next_str)
            self._compact_next_label.config(text=next_str)
        else:
            self._compact_next_label.config(text="")

        self._level_after = self.after(100, self._update_level)

    # ------------------------------------------------------------------
    # Log helpers
    # ------------------------------------------------------------------

    def _log_append(self, text: str) -> None:
        self._log.config(state="normal")
        self._log.insert("end", text)
        self._log.see("end")
        self._log.config(state="disabled")

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def _on_close(self) -> None:
        if getattr(self, "_checking_audit_day", False):
            logger.info("Close ignored: scope readiness check is running")
            return
        if self._proc is not None:
            messagebox.showinfo(
                "終了できません",
                "録音中は終了できません。\n先に「■ 停止」ボタンで録音を停止してください。",
                parent=self,
            )
            return
        if not messagebox.askyesno(
            "終了確認",
            "本当に終了してもよろしいですか？",
            parent=self,
        ):
            return
        logger.info("GUI closing")
        if self._level_after:
            self.after_cancel(self._level_after)
        if self._test_active:
            self._stop_audio_test()
        self._stop()
        for p in self._mock_procs:
            try:
                p.terminate()
            except Exception:
                pass
        self._mock_procs.clear()
        self.destroy()


if __name__ == "__main__":
    configure_logging()
    _GUI_INSTANCE_LOCK = SingleInstanceLock(GUI_LOCK_FILE)
    if not _GUI_INSTANCE_LOCK.acquire():
        logger.warning("GUI startup blocked: another instance is already running")
        root = tk.Tk()
        root.withdraw()
        messagebox.showwarning(
            "Desktop Audio Capture",
            "Desktop Audio Capture は既に起動しています。",
            parent=root,
        )
        root.destroy()
        sys.exit(2)
    app = App()
    try:
        app.mainloop()
    finally:
        _GUI_INSTANCE_LOCK.release()
